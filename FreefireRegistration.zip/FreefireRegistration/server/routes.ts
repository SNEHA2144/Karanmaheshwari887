import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { teamValidationSchema, playerValidationSchema } from "@shared/schema";
import { uploadMiddleware } from "./middleware/fileUpload";
import { initTelegramBot } from "./telegram-bot";
import path from "path";
import fs from "fs";
import fetch from "node-fetch";
// Extend Express Request type to include file from multer
interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize uploads directory if it doesn't exist
  const uploadsDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  
  // Initialize Telegram bot for admin panel
  initTelegramBot(storage);
  
  // API endpoints
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok' });
  });
  
  // Verify FreeFire UID
  app.get('/api/verify-uid/:uid', async (req: Request, res: Response) => {
    const uid = req.params.uid;
    
    try {
      // Validate UID format
      const result = z.string().regex(/^\d{9,12}$/).safeParse(uid);
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid UID format. UID must be 9-12 digits." 
        });
      }
      
      // Use the real Free Fire API endpoint that you provided
      const apiUrl = `https://karan-info-c91h.vercel.app/api/player-info?id=${uid}`;
      
      console.log(`Calling Free Fire API: ${apiUrl}`);
      
      try {
        const response = await fetch(apiUrl);
        const data = await response.json() as {
          status: string;
          data?: {
            basic_info?: {
              name: string;
              level: number;
              id: string;
            }
          };
          message: string;
        };
        
        // Log the response for debugging
        console.log("API Response:", JSON.stringify(data));
        
        // Check if the API returned valid data
        // The real API returns data in a specific structure
        if (data.status === "success" && data.data && data.data.basic_info) {
          const playerInfo = data.data.basic_info;
          return res.json({
            success: true,
            message: "UID verified successfully",
            playerInfo: {
              username: playerInfo.name,
              level: playerInfo.level,
              verified: true
            }
          });
        } else {
          return res.json({ 
            success: false, 
            message: "Player not found with this UID",
            playerInfo: null
          });
        }
      } catch (apiError) {
        console.error("Error calling Free Fire API:", apiError);
        return res.json({ 
          success: false, 
          message: "Error verifying UID with Free Fire servers",
          playerInfo: null
        });
      }
    } catch (error) {
      console.error("Error verifying UID:", error);
      res.status(500).json({ 
        success: false, 
        message: "An error occurred while verifying the UID" 
      });
    }
  });
  
  // Team registration endpoint
  app.post('/api/register', uploadMiddleware.single('paymentScreenshot'), async (req: MulterRequest, res: Response) => {
    try {
      // Get form data
      const formData = JSON.parse(req.body.formData || '{}');
      
      // Validate the form data
      const validationResult = teamValidationSchema.safeParse(formData);
      
      if (!validationResult.success) {
        const validationError = fromZodError(validationResult.error);
        return res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: validationError.details 
        });
      }
      
      // Check if the payment screenshot is uploaded
      if (!req.file) {
        return res.status(400).json({ 
          success: false, 
          message: "Payment screenshot is required" 
        });
      }
      
      const { 
        teamName, 
        teamEmail, 
        teamContact, 
        paymentMethod,
        paymentAmount,
        paymentTransactionId,
        paymentDate,
        players: playersData, 
        acceptTerms 
      } = validationResult.data;
      
      // Prepare players data for storage
      // Note: teamId will be assigned by the storage implementation
      const playersList = playersData.map((player, index) => ({
        ...player,
        teamId: 0, // Placeholder, will be replaced by storage
        isCaptain: index === 0 // First player is captain
      }));
      
      // Create new team registration
      const newTeam = await storage.createTeam({
        teamName,
        teamEmail,
        teamContact,
        paymentScreenshot: req.file.filename,
        paymentMethod,
        paymentAmount,
        paymentTransactionId,
        paymentDate,
        registrationId: '',  // Will be generated in storage
        status: 'pending',
        players: playersList
      });
      
      // Notify admins through Telegram bot
      import('./telegram-bot').then(({ notifyAdmins }) => {
        notifyAdmins(storage, newTeam).catch(err => {
          console.error("Error notifying admins:", err);
        });
      });
      
      res.status(201).json({
        success: true,
        message: "Team registered successfully",
        registrationId: newTeam.registrationId,
        teamName: newTeam.teamName
      });
    } catch (error) {
      console.error("Error registering team:", error);
      res.status(500).json({ 
        success: false, 
        message: "An error occurred during registration" 
      });
    }
  });
  
  // Get uploaded payment screenshot
  app.get('/api/uploads/:filename', (req: Request, res: Response) => {
    const filename = req.params.filename;
    const filePath = path.join(process.cwd(), 'uploads', filename);
    
    // Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ 
        success: false, 
        message: "File not found" 
      });
    }
    
    res.sendFile(filePath);
  });
  
  return httpServer;
}
