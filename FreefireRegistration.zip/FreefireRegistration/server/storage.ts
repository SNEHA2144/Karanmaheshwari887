import { 
  teams, players, admins, 
  type Team, type InsertTeam, 
  type Player, type InsertPlayer,
  type Admin, type InsertAdmin
} from "@shared/schema";
import crypto from "crypto";

// Storage interface
export interface IStorage {
  // Team operations
  createTeam(team: InsertTeam & { players: InsertPlayer[] }): Promise<Team & { players: Player[] }>;
  getTeam(id: number): Promise<(Team & { players: Player[] }) | undefined>;
  getTeamByRegistrationId(registrationId: string): Promise<(Team & { players: Player[] }) | undefined>;
  getAllTeams(): Promise<(Team & { players: Player[] })[]>;
  updateTeamStatus(id: number, status: string, approvedBy?: string): Promise<Team | undefined>;
  
  // Admin operations
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  getAdminByTelegramId(telegramId: string): Promise<Admin | undefined>;
  getAllAdmins(): Promise<Admin[]>;
  updateAdminStatus(id: number, isActive: boolean): Promise<Admin | undefined>;
}

export class MemStorage implements IStorage {
  private teams: Map<number, Team>;
  private players: Map<number, Player>;
  private admins: Map<number, Admin>;
  private teamCurrentId: number;
  private playerCurrentId: number;
  private adminCurrentId: number;

  constructor() {
    this.teams = new Map();
    this.players = new Map();
    this.admins = new Map();
    this.teamCurrentId = 1;
    this.playerCurrentId = 1;
    this.adminCurrentId = 1;
    
    // Add default admin (for testing)
    this.createAdmin({
      telegramId: process.env.ADMIN_TELEGRAM_ID || "12345678",
      username: "admin",
      isActive: true
    });
  }

  async createTeam(teamData: InsertTeam & { players: InsertPlayer[] }): Promise<Team & { players: Player[] }> {
    const { players: playerData, ...teamInfo } = teamData;
    
    // Generate unique registration ID
    const registrationId = `FF-${new Date().getFullYear()}-${crypto.randomInt(10000, 99999)}`;
    
    // Create team
    const teamId = this.teamCurrentId++;
    const team: Team = { 
      ...teamInfo, 
      id: teamId, 
      registrationId,
      registeredAt: new Date(),
      status: "pending"
    };
    this.teams.set(teamId, team);
    
    // Create players
    const teamPlayers: Player[] = [];
    for (const player of playerData) {
      const playerId = this.playerCurrentId++;
      const newPlayer: Player = {
        ...player,
        id: playerId,
        teamId
      };
      this.players.set(playerId, newPlayer);
      teamPlayers.push(newPlayer);
    }
    
    return { ...team, players: teamPlayers };
  }

  async getTeam(id: number): Promise<(Team & { players: Player[] }) | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;
    
    const teamPlayers = Array.from(this.players.values()).filter(player => player.teamId === id);
    return { ...team, players: teamPlayers };
  }

  async getTeamByRegistrationId(registrationId: string): Promise<(Team & { players: Player[] }) | undefined> {
    const team = Array.from(this.teams.values()).find(team => team.registrationId === registrationId);
    if (!team) return undefined;
    
    const teamPlayers = Array.from(this.players.values()).filter(player => player.teamId === team.id);
    return { ...team, players: teamPlayers };
  }

  async getAllTeams(): Promise<(Team & { players: Player[] })[]> {
    const result: (Team & { players: Player[] })[] = [];
    
    for (const team of this.teams.values()) {
      const teamPlayers = Array.from(this.players.values()).filter(player => player.teamId === team.id);
      result.push({ ...team, players: teamPlayers });
    }
    
    return result;
  }

  async updateTeamStatus(id: number, status: string, approvedBy?: string): Promise<Team | undefined> {
    const team = this.teams.get(id);
    if (!team) return undefined;
    
    const updatedTeam: Team = {
      ...team,
      status,
      ...(status === "approved" ? { approvedAt: new Date(), approvedBy } : {})
    };
    
    this.teams.set(id, updatedTeam);
    return updatedTeam;
  }

  async createAdmin(admin: InsertAdmin): Promise<Admin> {
    const id = this.adminCurrentId++;
    const newAdmin: Admin = { ...admin, id };
    this.admins.set(id, newAdmin);
    return newAdmin;
  }

  async getAdminByTelegramId(telegramId: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find(admin => admin.telegramId === telegramId);
  }

  async getAllAdmins(): Promise<Admin[]> {
    return Array.from(this.admins.values());
  }

  async updateAdminStatus(id: number, isActive: boolean): Promise<Admin | undefined> {
    const admin = this.admins.get(id);
    if (!admin) return undefined;
    
    const updatedAdmin: Admin = { ...admin, isActive };
    this.admins.set(id, updatedAdmin);
    return updatedAdmin;
  }
}

export const storage = new MemStorage();
