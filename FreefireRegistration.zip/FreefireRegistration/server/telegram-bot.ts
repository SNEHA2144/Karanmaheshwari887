import TelegramBot from "node-telegram-bot-api";
import { IStorage } from "./storage";
import path from "path";
import fs from "fs";

// Bot commands
const COMMANDS = {
  START: "/start",
  HELP: "/help",
  LIST_TEAMS: "/list_teams",
  PENDING_TEAMS: "/pending_teams",
  TEAM_DETAILS: "/team_details",
  APPROVE_TEAM: "/approve_team",
  REJECT_TEAM: "/reject_team",
  STATS: "/stats",
  SEARCH: "/search",
  BROADCAST: "/broadcast",
  SET_STATUS: "/set_status",
  EXPORT_DATA: "/export_data",
  GENERATE_FIXTURES: "/generate_fixtures",
  UNLOCK: "/unlock_admin",
  SELF_REGISTER: "/i_am_admin"
};

// Bot instance
let bot: TelegramBot | null = null;

export function initTelegramBot(storage: IStorage) {
  // Get bot token from environment variables
  const token = process.env.TELEGRAM_BOT_TOKEN;
  
  if (!token) {
    console.log("TELEGRAM_BOT_TOKEN not provided, Telegram bot functionality disabled");
    return;
  }
  
  try {
    // Create bot instance
    bot = new TelegramBot(token, { polling: true });
    
    // Add the self-registration command
    bot.onText(/\/i_am_admin/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const username = msg.from?.username || "Admin";
      
      try {
        // Check if already registered
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (admin) {
          if (admin.isActive) {
            bot?.sendMessage(
              chatId, 
              "✅ You are already registered as an administrator."
            );
          } else {
            // Reactivate admin
            await storage.updateAdminStatus(admin.id, true);
            bot?.sendMessage(
              chatId, 
              "✅ Your administrator access has been reactivated."
            );
          }
        } else {
          // Register as a new admin
          await storage.createAdmin({
            telegramId: telegramId,
            username: username,
            isActive: true
          });
          
          bot?.sendMessage(
            chatId, 
            "🔐 *Administrator Access Granted*\n\n" +
            "You have been registered as an administrator of this tournament bot.\n\n" +
            "Type /help to see available commands.",
            { parse_mode: "Markdown" }
          );
        }
      } catch (error) {
        console.error("Error in self-registration:", error);
        bot?.sendMessage(
          chatId, 
          "❌ An error occurred while registering you as an admin. Please try again later."
        );
      }
    });
    
    // Start command handler
    bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const username = msg.from?.username || "Admin";
      
      try {
        // Check if user is an admin
        let admin = await storage.getAdminByTelegramId(telegramId);
        
        // If no admins exist in the system at all, register the first user as an admin
        if (!admin) {
          const allAdmins = await storage.getAllAdmins();
          
          if (allAdmins.length === 0) {
            // Auto-register the first user as an admin
            admin = await storage.createAdmin({
              telegramId: telegramId,
              username: username,
              isActive: true
            });
            
            bot?.sendMessage(
              chatId, 
              "🔐 *Administrator Access Granted*\n\n" +
              "You have been automatically registered as the first administrator of this tournament bot.\n\n" +
              "Welcome to the FreeFire Tournament Management System!"
            );
          } else {
            bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
            return;
          }
        } else if (!admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. Your admin account has been deactivated.");
          return;
        }
        
        // Welcome message with instructions
        const welcomeMessage = `
🎮 *Welcome to Free Fire Tournament Admin Panel* 🎮

You are authenticated as admin: ${admin.username || "Admin"}

*Basic Commands:*
${COMMANDS.HELP} - Show this help message
${COMMANDS.LIST_TEAMS} - List all registered teams
${COMMANDS.PENDING_TEAMS} - List pending registrations

*Team Management:*
${COMMANDS.TEAM_DETAILS} ID - View team details (e.g. /team_details FF-2023-12345)
${COMMANDS.APPROVE_TEAM} ID - Approve team (e.g. /approve_team FF-2023-12345)
${COMMANDS.REJECT_TEAM} ID - Reject team (e.g. /reject_team FF-2023-12345)
${COMMANDS.SET_STATUS} ID STATUS - Set custom status (e.g. /set_status FF-2023-12345 qualified)

*Tournament Tools:*
${COMMANDS.STATS} - Show registration statistics
${COMMANDS.SEARCH} QUERY - Search for teams or players (e.g. /search dragon)
${COMMANDS.BROADCAST} MESSAGE - Send message to all approved teams
${COMMANDS.EXPORT_DATA} - Export registration data as CSV
${COMMANDS.GENERATE_FIXTURES} - Generate tournament fixtures and groups
        `;
        
        bot?.sendMessage(chatId, welcomeMessage, { parse_mode: "Markdown" });
      } catch (error) {
        console.error("Error handling /start command:", error);
        bot?.sendMessage(chatId, "An error occurred. Please try again later.");
      }
    });
    
    // Help command handler
    bot.onText(/\/help/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const username = msg.from?.username || "Admin";
      
      try {
        // Check if user is an admin
        let admin = await storage.getAdminByTelegramId(telegramId);
        
        // If no admins exist in the system at all, register the first user as an admin
        if (!admin) {
          const allAdmins = await storage.getAllAdmins();
          
          if (allAdmins.length === 0) {
            // Auto-register the first user as an admin
            admin = await storage.createAdmin({
              telegramId: telegramId,
              username: username,
              isActive: true
            });
            
            bot?.sendMessage(
              chatId, 
              "🔐 *Administrator Access Granted*\n\n" +
              "You have been automatically registered as the first administrator of this tournament bot."
            );
          } else {
            bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
            return;
          }
        } else if (!admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. Your admin account has been deactivated.");
          return;
        }
        
        // Help message
        const helpMessage = `
*Free Fire Tournament Admin Commands:*

*Basic Commands:*
${COMMANDS.HELP} - Show this help message
${COMMANDS.LIST_TEAMS} - List all registered teams
${COMMANDS.PENDING_TEAMS} - List pending registrations

*Team Management:*
${COMMANDS.TEAM_DETAILS} ID - View team details (e.g. /team_details FF-2023-12345)
${COMMANDS.APPROVE_TEAM} ID - Approve team (e.g. /approve_team FF-2023-12345)
${COMMANDS.REJECT_TEAM} ID - Reject team (e.g. /reject_team FF-2023-12345)
${COMMANDS.SET_STATUS} ID STATUS - Set custom status (e.g. /set_status FF-2023-12345 qualified)

*Payment Verification:*
/payment_screenshot ID - View payment screenshot (e.g. /payment_screenshot FF-2023-12345)

*Tournament Tools:*
${COMMANDS.STATS} - Show registration statistics
${COMMANDS.SEARCH} QUERY - Search for teams or players (e.g. /search dragon)
${COMMANDS.BROADCAST} MESSAGE - Send message to all approved teams
${COMMANDS.EXPORT_DATA} - Export registration data as CSV
${COMMANDS.GENERATE_FIXTURES} - Generate tournament fixtures and groups
        `;
        
        bot?.sendMessage(chatId, helpMessage, { parse_mode: "Markdown" });
      } catch (error) {
        console.error("Error handling /help command:", error);
        bot?.sendMessage(chatId, "An error occurred. Please try again later.");
      }
    });
    
    // List teams command handler
    bot.onText(/\/list_teams/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all teams
        const teams = await storage.getAllTeams();
        
        if (teams.length === 0) {
          bot?.sendMessage(chatId, "No teams registered yet.");
          return;
        }
        
        // Create list message
        let message = "📋 *Registered Teams*\n\n";
        
        teams.forEach((team, index) => {
          const statusEmoji = team.status === "approved" ? "✅" : 
                             team.status === "rejected" ? "❌" : "⏳";
          
          message += `${index + 1}. ${statusEmoji} *${team.teamName}*\n`;
          message += `   ID: \`${team.registrationId}\`\n`;
          message += `   Status: ${team.status}\n\n`;
        });
        
        message += "Use /team_details ID to view detailed information.";
        
        bot?.sendMessage(chatId, message, { parse_mode: "Markdown" });
      } catch (error) {
        console.error("Error handling /list_teams command:", error);
        bot?.sendMessage(chatId, "An error occurred while fetching teams.");
      }
    });
    
    // Pending teams command handler
    bot.onText(/\/pending_teams/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all teams
        const teams = await storage.getAllTeams();
        const pendingTeams = teams.filter(team => team.status === "pending");
        
        if (pendingTeams.length === 0) {
          bot?.sendMessage(chatId, "No pending registrations.");
          return;
        }
        
        // Create list message
        let message = "⏳ *Pending Registrations*\n\n";
        
        pendingTeams.forEach((team, index) => {
          message += `${index + 1}. *${team.teamName}*\n`;
          message += `   ID: \`${team.registrationId}\`\n`;
          message += `   Registered: ${new Date(team.registeredAt).toLocaleString()}\n\n`;
        });
        
        message += "Use /team_details ID to view detailed information.";
        
        bot?.sendMessage(chatId, message, { parse_mode: "Markdown" });
      } catch (error) {
        console.error("Error handling /pending_teams command:", error);
        bot?.sendMessage(chatId, "An error occurred while fetching pending teams.");
      }
    });
    
    // Team details command handler
    bot.onText(/\/team_details (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const registrationId = match?.[1];
      
      if (!registrationId) {
        bot?.sendMessage(chatId, "Please provide a registration ID. Usage: /team_details ID");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get team details
        const team = await storage.getTeamByRegistrationId(registrationId);
        
        if (!team) {
          bot?.sendMessage(chatId, `Team with registration ID ${registrationId} not found.`);
          return;
        }
        
        // Create details message
        let message = `🎮 *Team Details: ${team.teamName}*\n\n`;
        
        message += `📋 *Registration Information*\n`;
        message += `ID: \`${team.registrationId}\`\n`;
        message += `Email: ${team.teamEmail}\n`;
        message += `Contact: ${team.teamContact}\n`;
        message += `Registered: ${new Date(team.registeredAt).toLocaleString()}\n`;
        message += `Status: ${team.status}\n\n`;
        
        message += `💰 *Payment Information*\n`;
        message += `Method: ${team.paymentMethod || 'N/A'}\n`;
        message += `Amount: ${team.paymentAmount || '500'}\n`;
        message += `Transaction ID: ${team.paymentTransactionId || 'N/A'}\n`;
        message += `Payment Date: ${team.paymentDate || 'N/A'}\n`;
        message += `Screenshot: Available\n\n`;
        
        if (team.status === "approved") {
          message += `Approved at: ${team.approvedAt ? new Date(team.approvedAt).toLocaleString() : 'N/A'}\n`;
          message += `Approved by: ${team.approvedBy || 'N/A'}\n\n`;
        }
        
        message += `👥 *Players*\n`;
        team.players.forEach((player, index) => {
          message += `${index + 1}. ${player.isCaptain ? '👑 ' : ''}*${player.name}*\n`;
          message += `   UID: ${player.uid}\n`;
          message += `   Username: ${player.username}\n`;
          message += `   Level: ${player.level}\n\n`;
        });
        
        message += `Use /approve_team ${registrationId} to approve this registration.\n`;
        message += `Use /reject_team ${registrationId} to reject this registration.`;
        
        // Send text message
        await bot?.sendMessage(chatId, message, { parse_mode: "Markdown" });
        
        // Send payment screenshot
        const filePath = path.join(process.cwd(), "uploads", team.paymentScreenshot);
        
        if (fs.existsSync(filePath)) {
          await bot?.sendPhoto(chatId, filePath, { 
            caption: `Payment screenshot for ${team.teamName} (${team.registrationId})`
          });
        } else {
          await bot?.sendMessage(chatId, "Payment screenshot not found.");
        }
      } catch (error) {
        console.error("Error handling /team_details command:", error);
        bot?.sendMessage(chatId, "An error occurred while fetching team details.");
      }
    });
    
    // Approve team command handler
    bot.onText(/\/approve_team (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const registrationId = match?.[1];
      
      if (!registrationId) {
        bot?.sendMessage(chatId, "Please provide a registration ID. Usage: /approve_team ID");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get team details
        const team = await storage.getTeamByRegistrationId(registrationId);
        
        if (!team) {
          bot?.sendMessage(chatId, `Team with registration ID ${registrationId} not found.`);
          return;
        }
        
        if (team.status === "approved") {
          bot?.sendMessage(chatId, `Team ${team.teamName} is already approved.`);
          return;
        }
        
        // Update team status
        const adminUsername = admin.username || String(admin.telegramId);
        await storage.updateTeamStatus(team.id, "approved", adminUsername);
        
        bot?.sendMessage(chatId, `✅ Team ${team.teamName} (${team.registrationId}) has been approved.`);
      } catch (error) {
        console.error("Error handling /approve_team command:", error);
        bot?.sendMessage(chatId, "An error occurred while approving the team.");
      }
    });
    
    // Reject team command handler
    bot.onText(/\/reject_team (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const registrationId = match?.[1];
      
      if (!registrationId) {
        bot?.sendMessage(chatId, "Please provide a registration ID. Usage: /reject_team ID");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get team details
        const team = await storage.getTeamByRegistrationId(registrationId);
        
        if (!team) {
          bot?.sendMessage(chatId, `Team with registration ID ${registrationId} not found.`);
          return;
        }
        
        if (team.status === "rejected") {
          bot?.sendMessage(chatId, `Team ${team.teamName} is already rejected.`);
          return;
        }
        
        // Update team status
        const adminUsername = admin.username || String(admin.telegramId);
        await storage.updateTeamStatus(team.id, "rejected", adminUsername);
        
        bot?.sendMessage(chatId, `❌ Team ${team.teamName} (${team.registrationId}) has been rejected.`);
      } catch (error) {
        console.error("Error handling /reject_team command:", error);
        bot?.sendMessage(chatId, "An error occurred while rejecting the team.");
      }
    });
    
    // Stats command handler
    bot.onText(/\/stats/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all teams
        const teams = await storage.getAllTeams();
        
        if (teams.length === 0) {
          bot?.sendMessage(chatId, "No teams registered yet.");
          return;
        }
        
        // Calculate statistics
        const totalTeams = teams.length;
        const approvedTeams = teams.filter(team => team.status === "approved").length;
        const pendingTeams = teams.filter(team => team.status === "pending").length;
        const rejectedTeams = teams.filter(team => team.status === "rejected").length;
        const otherStatus = totalTeams - approvedTeams - pendingTeams - rejectedTeams;
        
        // Player statistics
        const totalPlayers = teams.reduce((sum, team) => sum + team.players.length, 0);
        const captains = teams.reduce((sum, team) => {
          return sum + team.players.filter(player => player.isCaptain).length;
        }, 0);
        
        // Average team level (based on player levels)
        const avgTeamLevel = teams.reduce((sum, team) => {
          const teamAvgLevel = team.players.reduce((s, p) => s + p.level, 0) / team.players.length;
          return sum + teamAvgLevel;
        }, 0) / totalTeams;
        
        // Create stats message
        const message = `
📊 *Tournament Registration Statistics*

*Team Statistics:*
• Total Registrations: ${totalTeams}
• Approved Teams: ${approvedTeams} (${Math.round(approvedTeams/totalTeams*100)}%)
• Pending Teams: ${pendingTeams} (${Math.round(pendingTeams/totalTeams*100)}%)
• Rejected Teams: ${rejectedTeams} (${Math.round(rejectedTeams/totalTeams*100)}%)
${otherStatus > 0 ? `• Other Status: ${otherStatus}\n` : ''}

*Player Statistics:*
• Total Players: ${totalPlayers}
• Team Captains: ${captains}
• Average Team Level: ${avgTeamLevel.toFixed(1)}

*Recent Activity:*
• Last Registration: ${teams.length > 0 ? new Date(teams[teams.length-1].registeredAt).toLocaleString() : 'N/A'}
• Last Approval: ${teams.find(t => t.approvedAt) ? 
    new Date(teams.find(t => t.approvedAt)?.approvedAt || 0).toLocaleString() : 'N/A'}

Use /list_teams to see all registered teams.
        `;
        
        bot?.sendMessage(chatId, message, { parse_mode: "Markdown" });
      } catch (error) {
        console.error("Error handling /stats command:", error);
        bot?.sendMessage(chatId, "An error occurred while generating statistics.");
      }
    });
    
    // Search command handler
    bot.onText(/\/search (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const searchQuery = match?.[1]?.toLowerCase();
      
      if (!searchQuery) {
        bot?.sendMessage(chatId, "Please provide a search term. Usage: /search [term]");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all teams
        const teams = await storage.getAllTeams();
        
        if (teams.length === 0) {
          bot?.sendMessage(chatId, "No teams registered yet.");
          return;
        }
        
        // Search in team names and player info
        const matchingTeams = teams.filter(team => {
          // Check team name
          if (team.teamName.toLowerCase().includes(searchQuery)) return true;
          
          // Check team email
          if (team.teamEmail.toLowerCase().includes(searchQuery)) return true;
          
          // Check team contact
          if (team.teamContact.toLowerCase().includes(searchQuery)) return true;
          
          // Check registration ID
          if (team.registrationId.toLowerCase().includes(searchQuery)) return true;
          
          // Check players
          return team.players.some(player => 
            player.name.toLowerCase().includes(searchQuery) ||
            player.uid.toLowerCase().includes(searchQuery) ||
            player.username.toLowerCase().includes(searchQuery)
          );
        });
        
        if (matchingTeams.length === 0) {
          bot?.sendMessage(chatId, `No results found for "${searchQuery}".`);
          return;
        }
        
        // Create search results message
        let message = `🔍 *Search Results for "${searchQuery}"*\n\n`;
        message += `Found ${matchingTeams.length} matching team(s):\n\n`;
        
        matchingTeams.forEach((team, index) => {
          const statusEmoji = team.status === "approved" ? "✅" : 
                             team.status === "rejected" ? "❌" : "⏳";
          
          message += `${index + 1}. ${statusEmoji} *${team.teamName}*\n`;
          message += `   ID: \`${team.registrationId}\`\n`;
          
          // Add matching players if any
          const matchingPlayers = team.players.filter(player => 
            player.name.toLowerCase().includes(searchQuery) ||
            player.uid.toLowerCase().includes(searchQuery) ||
            player.username.toLowerCase().includes(searchQuery)
          );
          
          if (matchingPlayers.length > 0) {
            message += `   Matching Players:\n`;
            matchingPlayers.forEach(player => {
              message += `   • ${player.isCaptain ? '👑 ' : ''}${player.name} (${player.username})\n`;
            });
          }
          
          message += `\n`;
        });
        
        message += `Use /team_details ID to view complete information.`;
        
        bot?.sendMessage(chatId, message, { parse_mode: "Markdown" });
      } catch (error) {
        console.error("Error handling /search command:", error);
        bot?.sendMessage(chatId, "An error occurred while searching.");
      }
    });
    
    // Set team status command handler
    bot.onText(/\/set_status (.+) (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const registrationId = match?.[1];
      const newStatus = match?.[2]?.toLowerCase();
      
      if (!registrationId || !newStatus) {
        bot?.sendMessage(chatId, "Please provide both registration ID and status. Usage: /set_status ID STATUS");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get team details
        const team = await storage.getTeamByRegistrationId(registrationId);
        
        if (!team) {
          bot?.sendMessage(chatId, `Team with registration ID ${registrationId} not found.`);
          return;
        }
        
        // Update team status
        const adminUsername = admin.username || String(admin.telegramId);
        await storage.updateTeamStatus(team.id, newStatus, adminUsername);
        
        bot?.sendMessage(chatId, `✅ Team ${team.teamName} status has been updated to "${newStatus}".`);
      } catch (error) {
        console.error("Error handling /set_status command:", error);
        bot?.sendMessage(chatId, "An error occurred while updating team status.");
      }
    });
    
    // Broadcast message command handler
    bot.onText(/\/broadcast (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const broadcastMessage = match?.[1];
      
      if (!broadcastMessage) {
        bot?.sendMessage(chatId, "Please provide a message to broadcast. Usage: /broadcast YOUR_MESSAGE");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all approved teams
        const teams = await storage.getAllTeams();
        const approvedTeams = teams.filter(team => team.status === "approved");
        
        if (approvedTeams.length === 0) {
          bot?.sendMessage(chatId, "No approved teams to broadcast message to.");
          return;
        }
        
        // Confirm before sending
        bot?.sendMessage(
          chatId, 
          `📢 *Broadcast Preview*\n\nThis message will be sent to ${approvedTeams.length} approved teams:\n\n${broadcastMessage}\n\n` +
          `Are you sure you want to send this broadcast? Reply with /confirm_broadcast to proceed.`,
          { parse_mode: "Markdown" }
        );
        
        // Store broadcast info for confirmation
        // (In a real implementation, this would use a proper state management system)
        // For demo purposes, we'll just acknowledge the broadcast request
        bot?.sendMessage(chatId, "⚠️ This is a demo. In a real implementation, the message would be sent to all team contacts.");
        
      } catch (error) {
        console.error("Error handling /broadcast command:", error);
        bot?.sendMessage(chatId, "An error occurred while preparing broadcast.");
      }
    });
    
    // Export data command handler
    bot.onText(/\/export_data/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all teams
        const teams = await storage.getAllTeams();
        
        if (teams.length === 0) {
          bot?.sendMessage(chatId, "No teams registered yet.");
          return;
        }
        
        // Create CSV content
        let csvContent = "Team ID,Team Name,Email,Contact,Status,Payment Method,Transaction ID,Registration Date\n";
        
        teams.forEach(team => {
          csvContent += `${team.registrationId},${team.teamName},${team.teamEmail},${team.teamContact},`;
          csvContent += `${team.status},${team.paymentMethod || 'N/A'},${team.paymentTransactionId || 'N/A'},`;
          csvContent += `${new Date(team.registeredAt).toISOString()}\n`;
        });
        
        // In a real implementation, we would create a file and send it
        // For demo purposes, we'll just send a preview
        bot?.sendMessage(
          chatId, 
          `📊 *Data Export Preview*\n\n\`\`\`\n${csvContent.substring(0, 300)}...\n\`\`\`\n\n` +
          `In a real implementation, a complete CSV file would be generated and sent to you.`,
          { parse_mode: "Markdown" }
        );
        
      } catch (error) {
        console.error("Error handling /export_data command:", error);
        bot?.sendMessage(chatId, "An error occurred while exporting data.");
      }
    });
    
    // Generate fixtures command handler
    bot.onText(/\/generate_fixtures/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get all approved teams
        const teams = await storage.getAllTeams();
        const approvedTeams = teams.filter(team => team.status === "approved");
        
        if (approvedTeams.length < 4) {
          bot?.sendMessage(chatId, "Not enough approved teams to generate fixtures. Need at least 4 teams.");
          return;
        }
        
        // In a real implementation, we would generate real fixtures based on team count
        // For demo purposes, we'll just show a sample fixture structure
        const groupCount = Math.floor(approvedTeams.length / 4);
        let message = `🏆 *Tournament Fixtures Generator*\n\n`;
        
        message += `Found ${approvedTeams.length} approved teams\n`;
        message += `Generating ${groupCount} groups of 4 teams each\n\n`;
        
        message += `*Group Stage:*\n`;
        for (let i = 0; i < Math.min(3, groupCount); i++) {
          message += `\nGroup ${String.fromCharCode(65 + i)}:\n`;
          const startIdx = i * 4;
          for (let j = 0; j < Math.min(4, approvedTeams.length - startIdx); j++) {
            const teamIdx = startIdx + j;
            if (teamIdx < approvedTeams.length) {
              message += `${j+1}. ${approvedTeams[teamIdx].teamName}\n`;
            }
          }
        }
        
        if (groupCount > 3) {
          message += `\n... and ${groupCount - 3} more groups\n`;
        }
        
        message += `\n*Sample Matches:*\n`;
        message += `Round 1: Team A vs Team B, Team C vs Team D\n`;
        message += `Round 2: Team A vs Team C, Team B vs Team D\n`;
        message += `Round 3: Team A vs Team D, Team B vs Team C\n\n`;
        
        message += `In a real implementation, complete fixtures would be generated based on team count and tournament format.`;
        
        bot?.sendMessage(chatId, message, { parse_mode: "Markdown" });
        
      } catch (error) {
        console.error("Error handling /generate_fixtures command:", error);
        bot?.sendMessage(chatId, "An error occurred while generating fixtures.");
      }
    });
    
    // Self-registration as admin
    bot.onText(/\/i_am_admin/, async (msg) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const username = msg.from?.username || "Admin";
      
      try {
        // Check if user is already registered
        let admin = await storage.getAdminByTelegramId(telegramId);
        
        if (admin) {
          if (admin.isActive) {
            bot?.sendMessage(
              chatId, 
              "✅ You are already registered as an administrator."
            );
          } else {
            // Re-activate admin
            admin = await storage.updateAdminStatus(admin.id, true);
            
            bot?.sendMessage(
              chatId, 
              "✅ Your administrator access has been reactivated."
            );
          }
          return;
        }
        
        // Register as a new admin
        admin = await storage.createAdmin({
          telegramId: telegramId,
          username: username,
          isActive: true
        });
        
        // Send success message
        bot?.sendMessage(
          chatId, 
          "🔐 *Administrator Access Granted*\n\n" +
          "You have been registered as an administrator of this tournament bot.\n\n" +
          "Type /help to see available commands.",
          { parse_mode: "Markdown" }
        );
      } catch (error) {
        console.error("Error handling self-registration:", error);
        bot?.sendMessage(chatId, "An error occurred while registering you as an admin. Please try again later.");
      }
    });
    
    // Get payment screenshot command
    bot.onText(/\/payment_screenshot (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const telegramId = String(msg.from?.id);
      const registrationId = match?.[1];
      
      if (!registrationId) {
        bot?.sendMessage(chatId, "Please provide a registration ID. Usage: /payment_screenshot ID");
        return;
      }
      
      try {
        // Check if user is an admin
        const admin = await storage.getAdminByTelegramId(telegramId);
        
        if (!admin || !admin.isActive) {
          bot?.sendMessage(chatId, "⛔ Access denied. You are not authorized to use this bot.");
          return;
        }
        
        // Get team details
        const team = await storage.getTeamByRegistrationId(registrationId);
        
        if (!team) {
          bot?.sendMessage(chatId, `Team with registration ID ${registrationId} not found.`);
          return;
        }
        
        // Check if payment screenshot exists
        if (!team.paymentScreenshot) {
          bot?.sendMessage(chatId, `❌ Team ${team.teamName} has not uploaded a payment screenshot.`);
          return;
        }
        
        // Get the full path to the screenshot
        const baseUrl = process.env.BASE_URL || `http://localhost:5000`;
        const screenshotUrl = `${baseUrl}/api/uploads/${team.paymentScreenshot.split('/').pop()}`;
        
        // Send info message with link to screenshot
        bot?.sendMessage(
          chatId,
          `💰 *Payment Screenshot for ${team.teamName}*\n\n` +
          `• Transaction ID: \`${team.paymentTransactionId || 'N/A'}\`\n` +
          `• Payment Method: ${team.paymentMethod || 'UPI'}\n` +
          `• Amount: ₹${team.paymentAmount || '500'}\n` +
          `• Date: ${team.paymentDate ? new Date(team.paymentDate).toLocaleDateString() : 'N/A'}\n\n` +
          `View the full-size screenshot: ${screenshotUrl}`,
          { parse_mode: "Markdown" }
        );
        
        // Inform about direct photo capability
        bot?.sendMessage(
          chatId,
          "Note: With proper permissions configured, this bot could send the payment screenshot directly as a photo instead of a link."
        );
        
      } catch (error) {
        console.error("Error handling /payment_screenshot command:", error);
        bot?.sendMessage(chatId, "An error occurred while retrieving the payment screenshot.");
      }
    });
    
    // Set up notification for new registrations
    console.log("Telegram bot initialized successfully!");
  } catch (error) {
    console.error("Error initializing Telegram bot:", error);
  }
}

// Helper function to return the access denied message with self-registration instructions
function getAccessDeniedMessage(): string {
  return "⛔ *Access Denied*\n\n" +
         "You are not authorized to use this bot.\n\n" +
         "To register yourself as an administrator, use the command:\n" +
         "`/i_am_admin`";
}

// Function to notify admins about new registrations
export async function notifyAdmins(storage: IStorage, team: any) {
  if (!bot) return;
  
  try {
    // Get all active admins
    const admins = await storage.getAllAdmins();
    
    if (admins.length === 0) return;
    
    // Notification message
    const message = `
🔔 *New Team Registration*

Team: *${team.teamName}*
ID: \`${team.registrationId}\`
Registered: ${new Date(team.registeredAt).toLocaleString()}
Payment Method: ${team.paymentMethod || 'N/A'}
Amount: ${team.paymentAmount || '₹500'}
Transaction ID: ${team.paymentTransactionId || 'N/A'}

Use /team_details ${team.registrationId} to view details.
    `;
    
    // Send notification to all admins
    for (const admin of admins) {
      if (admin.isActive) {
        // Send message first
        await bot.sendMessage(admin.telegramId, message, { parse_mode: "Markdown" });
        
        // If payment screenshot exists, send it as well
        if (team.paymentScreenshot) {
          try {
            // Get the full path to the screenshot
            const baseUrl = process.env.BASE_URL || `http://localhost:5000`;
            const screenshotUrl = `${baseUrl}/api/uploads/${team.paymentScreenshot.split('/').pop()}`;
            
            // Send a follow-up message with the screenshot URL and direct caption
            await bot.sendMessage(
              admin.telegramId,
              `💰 *Payment Screenshot*\n\nTransaction ID: \`${team.paymentTransactionId || 'N/A'}\`\n\nView the full-size screenshot: ${screenshotUrl}`,
              { parse_mode: "Markdown" }
            );
            
            // If we had a Telegram bot token with proper permissions, we could upload the image directly:
            // await bot.sendPhoto(admin.telegramId, screenshotUrl, {
            //   caption: `💰 Payment Screenshot\nTeam: ${team.teamName}\nTransaction ID: ${team.paymentTransactionId || 'N/A'}`,
            //   parse_mode: "Markdown"
            // });
          } catch (photoError) {
            console.error("Error sending payment screenshot:", photoError);
            await bot.sendMessage(
              admin.telegramId, 
              `⚠️ Payment screenshot is available but could not be sent automatically. Please view it at: /api/uploads/${team.paymentScreenshot.split('/').pop()}`
            );
          }
        } else {
          await bot.sendMessage(
            admin.telegramId,
            "⚠️ No payment screenshot was uploaded by this team."
          );
        }
      }
    }
  } catch (error) {
    console.error("Error notifying admins:", error);
  }
}
