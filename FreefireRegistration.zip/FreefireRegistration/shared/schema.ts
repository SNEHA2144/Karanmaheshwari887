import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Player schema
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull(),
  name: text("name").notNull(),
  uid: text("uid").notNull(),
  level: integer("level").notNull(),
  username: text("username").notNull(),
  isCaptain: boolean("is_captain").default(false).notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
});

// Team schema
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  teamName: text("team_name").notNull(),
  teamEmail: text("team_email").notNull(),
  teamContact: text("team_contact").notNull(),
  paymentScreenshot: text("payment_screenshot").notNull(),
  paymentMethod: text("payment_method").default("unspecified"),
  paymentAmount: text("payment_amount").default("500"),
  paymentTransactionId: text("payment_transaction_id"),
  paymentDate: text("payment_date"),
  registrationId: text("registration_id").notNull(),
  status: text("status").default("pending").notNull(),
  registeredAt: timestamp("registered_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
  approvedBy: text("approved_by"),
});

// Admin schema (for Telegram bot admins)
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  isActive: boolean("is_active").default(true).notNull(),
});

// Insert schemas
export const insertPlayerSchema = createInsertSchema(players).omit({ id: true });
export const insertTeamSchema = createInsertSchema(teams).omit({ 
  id: true, 
  registeredAt: true, 
  approvedAt: true, 
  approvedBy: true 
});
export const insertAdminSchema = createInsertSchema(admins).omit({ id: true });

// Custom validation schema for registration form
export const playerValidationSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters"),
  uid: z.string().regex(/^\d{9,12}$/, "UID must be 9-12 digits"),
  level: z.number().int().min(1, "Level must be at least 1").max(100, "Level cannot exceed 100"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  isCaptain: z.boolean().default(false),
  isVerified: z.boolean().default(false),
});

export const teamValidationSchema = z.object({
  teamName: z.string().min(3, "Team name must be at least 3 characters"),
  teamEmail: z.string().email("Please enter a valid email address"),
  teamContact: z.string().regex(/^\d{10,15}$/, "Contact must be 10-15 digits"),
  paymentMethod: z.string().min(1, "Payment method is required"),
  paymentAmount: z.string().min(1, "Payment amount is required"),
  paymentTransactionId: z.string().min(1, "Transaction ID is required"),
  paymentDate: z.string().min(1, "Payment date is required"),
  players: z.array(playerValidationSchema).length(4, "Exactly 4 players are required"),
  acceptTerms: z.boolean().refine(val => val === true, "You must accept the terms and conditions"),
});

// Types
export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;

export type PlayerFormData = z.infer<typeof playerValidationSchema>;
export type TeamFormData = z.infer<typeof teamValidationSchema>;
