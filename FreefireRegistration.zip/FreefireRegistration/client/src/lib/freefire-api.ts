/**
 * FreeFire API integration
 * 
 * This module handles communication with the FreeFire API
 * for player UID verification
 */

// Type definitions
interface VerifyUIDResponse {
  success: boolean;
  message: string;
  playerInfo?: {
    username: string;
    level: number;
    verified: boolean;
  };
}

/**
 * Verify a player's FreeFire UID
 * @param uid - The player UID to verify
 * @returns Promise with verification result
 */
export async function verifyPlayerUID(uid: string): Promise<VerifyUIDResponse> {
  try {
    // Basic client-side validation
    if (!uid) {
      return {
        success: false,
        message: 'UID is required'
      };
    }

    if (!/^\d{9,12}$/.test(uid)) {
      return {
        success: false,
        message: 'UID must be 9-12 digits'
      };
    }

    // Call the verification API
    const response = await fetch(`/api/verify-uid/${uid}`);
    const data = await response.json();

    // Return the API response
    return data;
  } catch (error) {
    console.error('Error verifying UID:', error);
    return {
      success: false,
      message: 'An error occurred during verification. Please try again.'
    };
  }
}
