import { FC } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, CheckCircle, AlertTriangle } from "lucide-react";

const RegistrationConfirmation: FC = () => {
  const [, params] = useRoute("/confirmation/:registrationId");
  const registrationId = params?.registrationId;

  // Mock function to get confirmation data from localStorage
  // In a real app, this would be fetched from the server
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/registrations/${registrationId}`],
    enabled: !!registrationId,
    // In a real application, this would use the actual API endpoint
    queryFn: async () => {
      // For demo purposes, we'll retrieve from localStorage
      const storedData = localStorage.getItem(`registration_${registrationId}`);
      
      if (storedData) {
        return JSON.parse(storedData);
      }
      
      // Simulate an API response if no stored data (for demo purposes)
      return {
        teamName: "Demo Team",
        registrationId: registrationId,
        status: "pending"
      };
    }
  });

  return (
    <div className="font-roboto text-foreground min-h-screen pb-8 bg-background flex flex-col">
      {/* Header */}
      <header className="bg-background border-b border-gray-800 py-3 px-4 mb-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <svg 
              width="48" 
              height="48" 
              viewBox="0 0 48 48" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className="h-12 mr-3"
            >
              <rect width="48" height="48" rx="8" fill="#1E1E1E"/>
              <path d="M24 12L34 18V30L24 36L14 30V18L24 12Z" stroke="#FF5722" strokeWidth="2"/>
              <path d="M24 20L28 22V26L24 28L20 26V22L24 20Z" fill="#FF5722"/>
              <path d="M18 17L20 18V22L18 23L16 22V18L18 17Z" fill="#FF5722"/>
              <path d="M30 17L32 18V22L30 23L28 22V18L30 17Z" fill="#FF5722"/>
              <path d="M18 25L20 26V30L18 31L16 30V26L18 25Z" fill="#FF5722"/>
              <path d="M30 25L32 26V30L30 31L28 30V26L30 25Z" fill="#FF5722"/>
            </svg>
            <h1 className="font-bold text-xl md:text-2xl uppercase tracking-wider text-primary">
              FreeFire <span className="text-white">Tournament Registration</span>
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 flex-grow flex items-center justify-center">
        <Card className="w-full max-w-md mx-auto overflow-hidden border border-primary">
          {isLoading ? (
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 bg-primary bg-opacity-20">
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
              </div>
              <h3 className="text-xl font-bold mb-2">Loading Registration Data...</h3>
              <div className="space-y-2 mt-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4 mx-auto" />
                <Skeleton className="h-4 w-5/6 mx-auto" />
              </div>
            </CardContent>
          ) : error ? (
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-error bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="h-8 w-8 text-error" />
              </div>
              <h3 className="text-xl font-bold mb-2">Registration Not Found</h3>
              <p className="text-muted-foreground mb-6">
                We couldn't find the registration information for ID: {registrationId}
              </p>
              <Button asChild className="w-full">
                <Link href="/">Return to Registration</Link>
              </Button>
            </CardContent>
          ) : (
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-success bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
              <h3 className="text-xl font-bold mb-2">Registration Successful!</h3>
              <p className="text-muted-foreground mb-6">
                Your team has been successfully registered for the tournament. 
                You will receive a confirmation email shortly.
              </p>
              
              <div className="bg-secondary bg-opacity-20 p-4 rounded-lg mb-6 text-left">
                <h4 className="text-primary font-medium mb-2">Registration Details</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="text-gray-400">Team Name:</span> <span>{data?.teamName}</span></p>
                  <p><span className="text-gray-400">Registration ID:</span> <span>{data?.registrationId}</span></p>
                  <p><span className="text-gray-400">Status:</span> <span className="text-yellow-400">Pending Approval</span></p>
                </div>
              </div>
              
              <Button asChild className="w-full">
                <Link href="/">Return to Home</Link>
              </Button>
            </CardContent>
          )}
        </Card>
      </main>

      {/* Footer */}
      <footer className="mt-12 bg-background border-t border-gray-800 py-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center">
            <p className="text-sm text-gray-400">
              © 2025 FreeFire Tournament. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default RegistrationConfirmation;
