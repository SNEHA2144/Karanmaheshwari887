import { FC } from "react";
import RegistrationForm from "@/components/RegistrationForm";

const Home: FC = () => {
  return (
    <div className="font-roboto text-foreground min-h-screen pb-8 bg-background">
      {/* Header */}
      <header className="bg-background border-b border-gray-800 py-3 px-4 mb-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <svg 
              width="48" 
              height="48" 
              viewBox="0 0 48 48" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
              className="h-12 mr-3"
            >
              <rect width="48" height="48" rx="8" fill="#1E1E1E"/>
              <path d="M24 12L34 18V30L24 36L14 30V18L24 12Z" stroke="#FF5722" strokeWidth="2"/>
              <path d="M24 20L28 22V26L24 28L20 26V22L24 20Z" fill="#FF5722"/>
              <path d="M18 17L20 18V22L18 23L16 22V18L18 17Z" fill="#FF5722"/>
              <path d="M30 17L32 18V22L30 23L28 22V18L30 17Z" fill="#FF5722"/>
              <path d="M18 25L20 26V30L18 31L16 30V26L18 25Z" fill="#FF5722"/>
              <path d="M30 25L32 26V30L30 31L28 30V26L30 25Z" fill="#FF5722"/>
            </svg>
            <h1 className="font-bold text-xl md:text-2xl uppercase tracking-wider text-primary">
              FreeFire <span className="text-white">Tournament Registration</span>
            </h1>
          </div>
          <div className="hidden md:block">
            <span className="text-sm font-medium bg-accent bg-opacity-20 text-accent px-3 py-1 rounded">
              Registration Open
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4">
        <RegistrationForm />
      </main>

      {/* Footer */}
      <footer className="mt-12 bg-background border-t border-gray-800 py-6">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center">
            <p className="text-sm text-gray-400">
              © 2025 FreeFire Tournament. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
