import { FC, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { teamValidationSchema, type TeamFormData } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useNavigation } from "@/hooks/use-navigation";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import PlayerDetailsForm from "./PlayerDetailsForm";
import PaymentUpload from "./PaymentUpload";
import ConfirmationModal from "./ConfirmationModal";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Users, FileText, CreditCard, CheckCircle } from "lucide-react";

const RegistrationForm: FC = () => {
  const { toast } = useToast();
  const navigate = useNavigation();
  const [paymentFile, setPaymentFile] = useState<File | null>(null);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [confirmationData, setConfirmationData] = useState<{
    teamName: string;
    registrationId: string;
  } | null>(null);

  // Initialize form with default values
  const form = useForm<TeamFormData>({
    resolver: zodResolver(teamValidationSchema),
    defaultValues: {
      teamName: "",
      teamEmail: "",
      teamContact: "",
      paymentMethod: "upi",
      paymentAmount: "500",
      paymentTransactionId: "",
      paymentDate: "",
      players: [
        { name: "", uid: "", level: 1, username: "", isCaptain: true, isVerified: false },
        { name: "", uid: "", level: 1, username: "", isCaptain: false, isVerified: false },
        { name: "", uid: "", level: 1, username: "", isCaptain: false, isVerified: false },
        { name: "", uid: "", level: 1, username: "", isCaptain: false, isVerified: false },
      ],
      acceptTerms: false,
    },
  });

  // Form submission mutation
  const submitMutation = useMutation({
    mutationFn: async (formData: TeamFormData) => {
      if (!paymentFile) {
        throw new Error("Payment screenshot is required");
      }

      // Create form data for file upload
      const submitData = new FormData();
      submitData.append("formData", JSON.stringify(formData));
      submitData.append("paymentScreenshot", paymentFile);

      const response = await apiRequest("POST", "/api/register", submitData);
      return response.json();
    },
    onSuccess: (data) => {
      setConfirmationData({
        teamName: data.teamName,
        registrationId: data.registrationId,
      });
      
      // Store in localStorage for the confirmation page
      localStorage.setItem(`registration_${data.registrationId}`, JSON.stringify({
        teamName: data.teamName,
        registrationId: data.registrationId,
        status: "pending"
      }));
      
      setIsConfirmationOpen(true);
    },
    onError: (error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Something went wrong during registration. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (data: TeamFormData) => {
    if (!paymentFile) {
      toast({
        title: "Payment screenshot missing",
        description: "Please upload a payment screenshot to complete your registration.",
        variant: "destructive",
      });
      return;
    }

    // Validate all form sections
    const teamDetailsValid = form.trigger(["teamName", "teamEmail", "teamContact"], { shouldFocus: true });
    const playersValid = form.trigger("players", { shouldFocus: true });
    const paymentValid = form.trigger(["paymentMethod", "paymentAmount", "paymentTransactionId", "paymentDate", "acceptTerms"], { shouldFocus: true });
    
    if (!teamDetailsValid || !playersValid || !paymentValid) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields correctly.",
        variant: "destructive",
      });
      return;
    }

    submitMutation.mutate(data);
  };

  // Handle confirmation modal close
  const handleConfirmationClose = () => {
    setIsConfirmationOpen(false);
    if (confirmationData?.registrationId) {
      navigate(`/confirmation/${confirmationData.registrationId}`);
    }
  };

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="max-w-4xl mx-auto">
          {/* Section headings */}
          <div className="text-center mb-12 bg-gradient-to-r from-primary/20 via-primary/30 to-primary/20 py-10 px-6 rounded-lg border border-primary/30">
            <h1 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary-foreground">Team Registration Form</h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Complete all sections below to register your team for the Free Fire tournament</p>
          </div>

          {/* Team Information Section */}
          <Card className="mb-8 border-primary/10 shadow-lg shadow-primary/5">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 border-b border-primary/20 py-5">
              <CardTitle className="font-bold uppercase tracking-wide flex items-center">
                <div className="bg-primary/20 p-2 rounded-full mr-3">
                  <Users className="text-primary h-5 w-5" />
                </div>
                Team Information
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8 bg-background/50">
              <FormField
                control={form.control}
                name="teamName"
                render={({ field }) => (
                  <FormItem className="mb-5">
                    <FormLabel>
                      Team Name <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter your team name"
                        {...field}
                        className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="teamEmail"
                render={({ field }) => (
                  <FormItem className="mb-5">
                    <FormLabel>
                      Team Email <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="team@example.com"
                        {...field}
                        className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="teamContact"
                render={({ field }) => (
                  <FormItem className="mb-4">
                    <FormLabel>
                      Team Captain Contact Number <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="tel"
                        placeholder="Enter contact number"
                        {...field}
                        className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Player Details Section */}
          <Card className="mb-8 border-primary/10 shadow-lg shadow-primary/5">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 border-b border-primary/20 py-5">
              <CardTitle className="font-bold uppercase tracking-wide flex items-center">
                <div className="bg-primary/20 p-2 rounded-full mr-3">
                  <FileText className="text-primary h-5 w-5" />
                </div>
                Player Details
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8 bg-background/50">
              <PlayerDetailsForm form={form} />
            </CardContent>
          </Card>

          {/* Payment Information Section */}
          <Card className="mb-8 border-primary/10 shadow-lg shadow-primary/5">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 border-b border-primary/20 py-5">
              <CardTitle className="font-bold uppercase tracking-wide flex items-center">
                <div className="bg-primary/20 p-2 rounded-full mr-3">
                  <CreditCard className="text-primary h-5 w-5" />
                </div>
                Payment Information
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8 bg-background/50">
              <div className="bg-gradient-to-r from-primary/5 to-background p-6 rounded-lg mb-8 border border-primary/20 shadow-inner">
                <div className="flex items-center mb-4">
                  <div className="bg-primary/20 p-2 rounded-full mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <rect width="20" height="14" x="2" y="5" rx="2" />
                      <line x1="2" x2="22" y1="10" y2="10" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold">Registration Fee</h3>
                </div>
                <div className="p-4 bg-background/50 rounded-md mb-6 flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground">Tournament Entry Fee</p>
                    <p className="font-bold text-lg">₹500<span className="text-sm font-normal text-muted-foreground"> per team</span></p>
                  </div>
                  <div className="bg-primary/10 p-2 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <circle cx="12" cy="12" r="10" />
                      <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" />
                      <path d="M12 18V6" />
                    </svg>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-center mb-3">
                    <div className="bg-primary/20 p-1.5 rounded-full mr-2.5">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <path d="M21 5V3H3v2" />
                        <path d="M3 12v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                        <path d="M3 8h18" />
                        <path d="M12 12h4" />
                      </svg>
                    </div>
                    <h3 className="font-medium">Payment Details</h3>
                  </div>
                  
                  <div className="flex flex-col items-center bg-background/80 p-4 rounded-lg border border-primary/10 mb-4">
                    <div className="bg-primary/10 p-3 rounded-full mb-3">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <path d="M16 2H8C6.34 2 5 3.34 5 5v14c0 1.66 1.34 3 3 3h8c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3z"></path>
                        <path d="M12 19h.01"></path>
                        <rect x="7" y="6" width="10" height="3"></rect>
                      </svg>
                    </div>
                    <h4 className="text-lg font-medium text-primary mb-2">UPI Payment</h4>
                    <p className="text-sm text-muted-foreground mb-3">Send payment using any UPI app</p>
                    <div className="bg-gradient-to-r from-primary/10 to-primary/5 py-3 px-6 rounded-md border border-primary/20 text-center mb-1">
                      <p className="text-sm text-muted-foreground">UPI ID</p>
                      <p className="font-bold text-base tracking-wide">freefire-tourney@ybl</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-amber-500/10 to-amber-600/10 border border-amber-500/20 p-4 rounded-md">
                  <div className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-400 mr-3 mt-0.5">
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="8" x2="12" y2="12"></line>
                      <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <div>
                      <p className="font-medium text-amber-200 mb-1">Important</p>
                      <p className="text-sm text-amber-100/80">Please make the payment before uploading the screenshot. Your registration will be confirmed only after payment verification.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Payment Method <span className="text-destructive">*</span>
                      </FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors">
                            <SelectValue placeholder="Select payment method" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="upi">UPI</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="paymentAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Payment Amount <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="text"
                          {...field}
                          placeholder="500"
                          className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="paymentTransactionId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Transaction ID <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="text"
                          {...field}
                          placeholder="Enter your transaction ID"
                          className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="paymentDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Payment Date <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          {...field}
                          className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <PaymentUpload setPaymentFile={setPaymentFile} />

              <FormField
                control={form.control}
                name="acceptTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-6">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>
                        I accept the tournament rules and regulations <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormDescription className="text-muted-foreground text-xs">
                        By checking this box, you confirm that all the information provided is accurate and you agree to the tournament rules.
                      </FormDescription>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-center mb-12 mt-8">
            <Button
              type="submit"
              className="w-full sm:w-auto px-12 py-7 text-lg font-bold bg-gradient-to-r from-primary to-primary-foreground hover:from-primary/90 hover:to-primary-foreground/90 shadow-xl shadow-primary/30 transition-all duration-300 rounded-md border border-primary/20 hover:scale-[1.02]"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? (
                <div className="flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 animate-spin">
                    <line x1="12" y1="2" x2="12" y2="6"></line>
                    <line x1="12" y1="18" x2="12" y2="22"></line>
                    <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
                    <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
                    <line x1="2" y1="12" x2="6" y2="12"></line>
                    <line x1="18" y1="12" x2="22" y2="12"></line>
                    <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
                    <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
                  </svg>
                  Submitting Registration...
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <CheckCircle className="mr-2 h-5 w-5" />
                  Complete Registration
                </div>
              )}
            </Button>
          </div>
        </form>
      </Form>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={isConfirmationOpen}
        onClose={handleConfirmationClose}
        registrationId={confirmationData?.registrationId || ""}
        teamName={confirmationData?.teamName || ""}
      />
    </>
  );
};

export default RegistrationForm;