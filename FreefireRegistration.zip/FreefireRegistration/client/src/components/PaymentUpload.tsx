import { FC, useState, useRef, DragEvent } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { FormMessage } from "@/components/ui/form";
import { UploadCloud, X, Image, FileText } from "lucide-react";

interface PaymentUploadProps {
  setPaymentFile: (file: File | null) => void;
}

const PaymentUpload: FC<PaymentUploadProps> = ({ setPaymentFile }) => {
  const [dragActive, setDragActive] = useState(false);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      setFileError("Invalid file type. Only JPEG, JPG, and PNG files are allowed.");
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setFileError("File is too large. Maximum size is 2MB.");
      return;
    }

    // Clear any previous errors
    setFileError(null);

    // Set file preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setFilePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Set file name
    setFileName(file.name);

    // Pass file to parent component
    setPaymentFile(file);
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const removeFile = () => {
    setFilePreview(null);
    setFileName(null);
    setFileError(null);
    setPaymentFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="mb-5">
      <label className="block mb-2 text-sm font-medium">
        Payment Screenshot <span className="text-destructive">*</span>
      </label>
      
      <div
        className={cn(
          "border-2 border-dashed rounded-lg p-6 transition-all duration-300",
          dragActive ? "border-primary/80 bg-primary/5" : "border-primary/20",
          filePreview ? "bg-background/70" : "bg-background/50",
          "cursor-pointer hover:border-primary hover:shadow-sm hover:shadow-primary/10"
        )}
        onClick={triggerFileInput}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input
          type="file"
          id="paymentScreenshot"
          ref={fileInputRef}
          accept="image/jpeg,image/png,image/jpg"
          className="hidden"
          onChange={handleFileChange}
        />
        
        {!filePreview ? (
          <div className="text-center py-8 flex flex-col items-center">
            <UploadCloud className="h-12 w-12 text-primary/70 mb-3" />
            <p className="mb-2 text-sm text-muted-foreground">
              <span className="block font-medium text-primary mb-1">Click to upload payment screenshot</span>
              or drag and drop
            </p>
            <p className="text-xs text-muted-foreground/70 bg-gray-800/30 rounded-full px-3 py-1">PNG, JPG or JPEG (MAX. 2MB)</p>
          </div>
        ) : (
          <div className="text-center relative">
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute -top-2 -right-2 h-6 w-6 shadow-md z-10"
              onClick={(e) => {
                e.stopPropagation();
                removeFile();
              }}
            >
              <X className="h-4 w-4" />
            </Button>
            <div className="flex flex-col items-center">
              <div className="mb-3 relative overflow-hidden group">
                <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity z-0"></div>
                <img 
                  src={filePreview} 
                  alt="Payment screenshot preview" 
                  className="max-h-48 max-w-full rounded-lg object-contain mx-auto z-0 shadow-sm border border-primary/10"
                />
              </div>
              <div className="flex items-center text-sm font-medium bg-gray-800/30 px-3 py-1 rounded-full">
                <FileText className="h-4 w-4 mr-2 text-primary/70" />
                <span className="truncate max-w-[200px]">{fileName}</span>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {fileError && (
        <FormMessage className="mt-2">{fileError}</FormMessage>
      )}
    </div>
  );
};

export default PaymentUpload;
