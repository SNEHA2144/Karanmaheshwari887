import { FC, useState } from "react";
import { UseFormReturn } from "react-hook-form";
import { TeamFormData } from "@shared/schema";
import { verifyPlayerUID } from "@/lib/freefire-api";
import { useToast } from "@/hooks/use-toast";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, XCircle, AlertCircle, Trash2, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogClose 
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface PlayerDetailsFormProps {
  form: UseFormReturn<TeamFormData>;
}

const PlayerDetailsForm: FC<PlayerDetailsFormProps> = ({ form }) => {
  const { toast } = useToast();
  const [verification, setVerification] = useState<Record<number, {
    status: 'idle' | 'loading' | 'success' | 'error';
    message: string;
  }>>({
    0: { status: 'idle', message: '' },
    1: { status: 'idle', message: '' },
    2: { status: 'idle', message: '' },
    3: { status: 'idle', message: '' },
  });
  
  // State for manual entry dialog
  const [showManualDialog, setShowManualDialog] = useState(false);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number | null>(null);
  const [manualUsername, setManualUsername] = useState('');
  const [manualLevel, setManualLevel] = useState('1');
  
  // State for remove player dialog
  const [showRemoveDialog, setShowRemoveDialog] = useState(false);
  const [playerToRemove, setPlayerToRemove] = useState<number | null>(null);

  const handleVerifyUID = async (index: number) => {
    const uid = form.getValues(`players.${index}.uid`);

    if (!uid) {
      toast({
        title: "Validation Error",
        description: "Please enter a UID before verifying",
        variant: "destructive",
      });
      return;
    }

    // Update verification status to loading
    setVerification(prev => ({
      ...prev,
      [index]: { status: 'loading', message: 'Verifying player UID...' }
    }));

    try {
      const result = await verifyPlayerUID(uid);

      if (result.success) {
        // Update verification status to success
        setVerification(prev => ({
          ...prev,
          [index]: { status: 'success', message: 'Player verified successfully' }
        }));

        // Update player data with verified info if available
        if (result.playerInfo) {
          form.setValue(`players.${index}.username`, result.playerInfo.username);
          form.setValue(`players.${index}.level`, result.playerInfo.level);
          form.setValue(`players.${index}.isVerified`, true);
        }
      } else {
        // Update verification status to error
        setVerification(prev => ({
          ...prev,
          [index]: { status: 'error', message: result.message }
        }));
        form.setValue(`players.${index}.isVerified`, false);
        
        // Show option to add details manually
        toast({
          title: "UID Verification Failed",
          description: (
            <div className="flex flex-col gap-2">
              <p>{result.message}</p>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleManualEntry(index)}
                className="mt-2"
              >
                Add Player Manually
              </Button>
            </div>
          ),
          variant: "destructive",
          duration: 5000,
        });
      }
    } catch (error) {
      // Update verification status to error
      setVerification(prev => ({
        ...prev,
        [index]: { status: 'error', message: 'Error verifying UID' }
      }));
      form.setValue(`players.${index}.isVerified`, false);
    }
  };
  
  const handleManualEntry = (index: number) => {
    setCurrentPlayerIndex(index);
    setManualUsername('');
    setManualLevel('1');
    setShowManualDialog(true);
  };
  
  const confirmManualEntry = () => {
    if (currentPlayerIndex === null) return;
    
    // Update the form with manually entered values
    form.setValue(`players.${currentPlayerIndex}.username`, manualUsername);
    form.setValue(`players.${currentPlayerIndex}.level`, parseInt(manualLevel) || 1);
    form.setValue(`players.${currentPlayerIndex}.isVerified`, true);
    
    // Update verification status
    setVerification(prev => ({
      ...prev,
      [currentPlayerIndex]: { 
        status: 'success', 
        message: 'Player added manually' 
      }
    }));
    
    // Close dialog and show success toast
    setShowManualDialog(false);
    toast({
      title: "Player Added",
      description: "Player information has been added manually",
      variant: "default",
    });
  };
  
  // Handle initiating player removal
  const handleRemovePlayer = (index: number) => {
    // Captain (first player) cannot be removed
    if (index === 0) {
      toast({
        title: "Cannot Remove Captain",
        description: "The team captain cannot be removed. You may update their information instead.",
        variant: "destructive",
      });
      return;
    }
    
    setPlayerToRemove(index);
    setShowRemoveDialog(true);
  };
  
  // Confirm player removal
  const confirmRemovePlayer = () => {
    if (playerToRemove === null) return;
    
    // Reset player data to default values
    form.setValue(`players.${playerToRemove}.name`, "");
    form.setValue(`players.${playerToRemove}.uid`, "");
    form.setValue(`players.${playerToRemove}.username`, "");
    form.setValue(`players.${playerToRemove}.level`, 1);
    form.setValue(`players.${playerToRemove}.isVerified`, false);
    
    // Reset verification status
    setVerification(prev => ({
      ...prev,
      [playerToRemove]: { 
        status: 'idle', 
        message: '' 
      }
    }));
    
    // Close dialog and show toast
    setShowRemoveDialog(false);
    toast({
      title: "Player Removed",
      description: `Player ${playerToRemove + 1} has been removed from the team.`,
      variant: "default",
    });
  };
  
  // Auto-fill player data with example values (for testing)
  const fillExampleData = (index: number) => {
    // Only fill data if fields are empty
    const playerData = form.getValues(`players.${index}`);
    if (playerData.name || playerData.uid || playerData.username) {
      toast({
        title: "Fields Not Empty",
        description: "Please clear the player fields first or remove the player before filling example data.",
        variant: "destructive",
      });
      return;
    }
    
    // Example data - we use generic patterns to avoid impersonating real accounts
    const exampleData = {
      name: `Player Example ${index + 1}`,
      uid: `${1000000000 + index}`,
      username: `FF_Player_${index + 1}`,
      level: Math.floor(Math.random() * 50) + 10, // Random level between 10-60
    };
    
    // Update form with example data
    form.setValue(`players.${index}.name`, exampleData.name);
    form.setValue(`players.${index}.uid`, exampleData.uid);
    form.setValue(`players.${index}.username`, exampleData.username);
    form.setValue(`players.${index}.level`, exampleData.level);
    form.setValue(`players.${index}.isVerified`, true);
    
    // Update verification status
    setVerification(prev => ({
      ...prev,
      [index]: { 
        status: 'success', 
        message: 'Example data added' 
      }
    }));
    
    toast({
      title: "Example Data Added",
      description: `Added example data for Player ${index + 1}`,
      variant: "default",
    });
  };

  return (
    <>
      {[0, 1, 2, 3].map(index => (
        <div key={index} className={`mb-6 ${index < 3 ? 'pb-6 border-b border-gray-800' : ''}`}>
          <div className="flex items-center mb-3">
            <div className={`flex items-center justify-center ${index === 0 ? 'bg-primary' : 'bg-primary bg-opacity-10'} rounded-full w-8 h-8 mr-3`}>
              <span className="text-primary-foreground font-medium">{index + 1}</span>
            </div>
            <h3 className="font-bold">Player {index + 1} {index === 0 && '(Captain)'}</h3>
            
            <div className="ml-auto flex items-center gap-2">
              {index === 0 ? (
                <Badge variant="outline" className="bg-accent bg-opacity-20 text-accent">
                  Captain
                </Badge>
              ) : (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemovePlayer(index)}
                  className="h-7 px-2.5 text-xs text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors flex items-center gap-1"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Remove
                </Button>
              )}
            </div>
          </div>
          
          <div className="md:grid md:grid-cols-2 gap-4">
            {/* Player Name */}
            <FormField
              control={form.control}
              name={`players.${index}.name`}
              render={({ field }) => (
                <FormItem className="mb-4 md:mb-0">
                  <FormLabel>
                    Full Name <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Full name"
                      {...field}
                      className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* UID with Verification */}
            <FormField
              control={form.control}
              name={`players.${index}.uid`}
              render={({ field }) => (
                <FormItem className="mb-4 md:mb-0">
                  <FormLabel>
                    FreeFire UID <span className="text-destructive">*</span>
                  </FormLabel>
                  <div className="relative">
                    <FormControl>
                      <Input
                        placeholder="Enter 9-12 digit UID"
                        {...field}
                        className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors pr-20"
                        onBlur={() => {
                          if (field.value && field.value.length >= 9 && field.value.length <= 12) {
                            handleVerifyUID(index);
                          }
                        }}
                      />
                    </FormControl>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                      {verification[index].status === 'loading' && (
                        <Loader2 className="h-4 w-4 text-muted-foreground animate-spin mr-2" />
                      )}
                      {verification[index].status === 'success' && (
                        <CheckCircle className="h-4 w-4 text-success mr-2" />
                      )}
                      {verification[index].status === 'error' && (
                        <XCircle className="h-4 w-4 text-destructive mr-2" />
                      )}
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleVerifyUID(index)}
                        className="text-xs h-6 text-muted-foreground hover:text-primary"
                      >
                        Verify
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    {verification[index].message && (
                      <p className={`mt-1 text-xs ${
                        verification[index].status === 'success' ? 'text-success' : 
                        verification[index].status === 'error' ? 'text-destructive' : 
                        'text-muted-foreground'
                      }`}>
                        {verification[index].message}
                      </p>
                    )}
                    
                    {/* Error state buttons */}
                    {verification[index].status === 'error' && (
                      <div className="flex items-center gap-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleManualEntry(index)}
                          className="mt-1 text-xs h-6 flex items-center gap-1 text-primary"
                        >
                          <AlertCircle className="h-3 w-3" />
                          Add Manually
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => fillExampleData(index)}
                          className="mt-1 text-xs h-6 flex items-center gap-1 text-green-500"
                        >
                          <CheckCircle className="h-3 w-3" />
                          Use Example
                        </Button>
                      </div>
                    )}
                    
                    {/* Idle state example data button */}
                    {verification[index].status === 'idle' && !form.getValues(`players.${index}.name`) && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => fillExampleData(index)}
                        className="mt-1 text-xs h-6 flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors"
                      >
                        <CheckCircle className="h-3 w-3" />
                        Use Example Data
                      </Button>
                    )}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="md:grid md:grid-cols-2 gap-4 mt-4">
            {/* Player Level */}
            <FormField
              control={form.control}
              name={`players.${index}.level`}
              render={({ field }) => (
                <FormItem className="mb-4 md:mb-0">
                  <FormLabel>
                    Player Level <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="Current level"
                      min={1}
                      max={100}
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                      className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* In-game Username */}
            <FormField
              control={form.control}
              name={`players.${index}.username`}
              render={({ field }) => (
                <FormItem className="mb-4 md:mb-0">
                  <FormLabel>
                    In-game Username <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="In-game username"
                      {...field}
                      className="bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      ))}
      
      {/* Manual Entry Dialog */}
      <Dialog open={showManualDialog} onOpenChange={setShowManualDialog}>
        <DialogContent className="sm:max-w-[425px] bg-gradient-to-b from-background to-background/95 border-primary/20">
          <DialogHeader>
            <DialogTitle>Manually Add Player Details</DialogTitle>
            <DialogDescription>
              Enter player details manually if UID verification failed.
              This is useful for new accounts or accounts not in the system yet.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="manual-username" className="text-right text-sm font-medium">
                Username
              </label>
              <Input
                id="manual-username"
                className="col-span-3 bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                value={manualUsername}
                onChange={(e) => setManualUsername(e.target.value)}
                placeholder="In-game username"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="manual-level" className="text-right text-sm font-medium">
                Level
              </label>
              <Input
                id="manual-level"
                className="col-span-3 bg-background/70 border-primary/20 focus:border-primary hover:border-primary/50 transition-colors"
                type="number"
                min="1"
                max="100"
                value={manualLevel}
                onChange={(e) => setManualLevel(e.target.value)}
                placeholder="Player level"
              />
            </div>
          </div>
          
          <DialogFooter className="gap-2 sm:gap-0">
            <Button 
              variant="outline" 
              className="border-primary/20 hover:bg-primary/5 transition-colors" 
              onClick={() => setShowManualDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={confirmManualEntry}
              className="bg-gradient-to-r from-primary to-primary-foreground hover:from-primary/90 hover:to-primary-foreground/90 transition-colors"
            >
              Add Player
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Remove Player Confirmation */}
      <AlertDialog open={showRemoveDialog} onOpenChange={setShowRemoveDialog}>
        <AlertDialogContent className="bg-gradient-to-b from-background to-background/95 border border-destructive/20">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Remove Player
            </AlertDialogTitle>
            <AlertDialogDescription>
              {playerToRemove !== null && (
                <>
                  Are you sure you want to remove Player {playerToRemove + 1}? 
                  This will clear all information for this player.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="bg-destructive/5 border border-destructive/10 rounded-md p-3 my-2">
            <p className="text-sm text-destructive/80 flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <span>Any information entered for this player will be permanently lost and cannot be recovered.</span>
            </p>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-destructive/20 text-muted-foreground hover:bg-destructive/5 hover:text-destructive transition-colors">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive hover:bg-destructive/90 transition-colors" 
              onClick={confirmRemovePlayer}
            >
              Remove Player
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default PlayerDetailsForm;
