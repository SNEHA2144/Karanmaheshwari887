import { FC } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle } from "lucide-react";

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  registrationId: string;
  teamName: string;
}

const ConfirmationModal: FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  registrationId,
  teamName,
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md border border-primary/20 bg-gradient-to-b from-background to-background/95 shadow-xl shadow-primary/10 overflow-hidden">
        <div className="absolute w-full h-full bg-[radial-gradient(circle_at_top_right,theme(colors.primary.DEFAULT/0.15),transparent_70%)] -z-10"></div>
        <div className="text-center py-4">
          <div className="w-20 h-20 bg-gradient-to-tr from-success/20 to-success/30 rounded-full flex items-center justify-center mx-auto mb-5 shadow-inner shadow-success/10 border border-success/30">
            <CheckCircle className="h-10 w-10 text-success" />
          </div>
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold mb-3">Registration Successful!</DialogTitle>
            <DialogDescription className="text-muted-foreground mb-6 max-w-sm mx-auto">
              Your team has been successfully registered for the tournament. 
              You will receive a confirmation email shortly.
            </DialogDescription>
          </DialogHeader>
          
          <div className="bg-gradient-to-r from-primary/5 to-background p-5 rounded-lg mb-6 text-left border border-primary/10 shadow-sm">
            <h4 className="text-primary font-medium mb-3 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <rect width="18" height="18" x="3" y="3" rx="2" />
                <path d="M3 9h18" />
                <path d="M9 21V9" />
              </svg>
              Registration Details
            </h4>
            <div className="space-y-3 text-sm">
              <p className="flex justify-between py-1 border-b border-primary/10">
                <span className="text-muted-foreground">Team Name:</span> 
                <span className="font-medium">{teamName}</span>
              </p>
              <p className="flex justify-between py-1 border-b border-primary/10">
                <span className="text-muted-foreground">Registration ID:</span> 
                <span className="font-mono tracking-wide bg-primary/10 px-2 py-0.5 rounded text-primary">{registrationId}</span>
              </p>
              <p className="flex justify-between py-1">
                <span className="text-muted-foreground">Status:</span> 
                <span className="bg-yellow-500/10 text-yellow-400 px-2 py-0.5 rounded font-medium flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-yellow-400 mr-1.5 animate-pulse"></span>
                  Pending Approval
                </span>
              </p>
            </div>
          </div>
          
          <Button 
            onClick={onClose} 
            className="w-full bg-gradient-to-r from-primary to-primary-foreground hover:from-primary/90 hover:to-primary-foreground/90 transition-colors py-6 shadow-lg shadow-primary/20"
          >
            View Registration Details
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ConfirmationModal;
