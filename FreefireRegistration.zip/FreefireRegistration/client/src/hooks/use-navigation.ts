import { useLocation } from 'wouter';

/**
 * A custom hook that provides navigation functionality similar to React Router's useNavigate
 * but using wouter's useLocation under the hood
 */
export function useNavigation() {
  const [, setLocation] = useLocation();
  
  const navigate = (to: string) => {
    setLocation(to);
  };
  
  return navigate;
}